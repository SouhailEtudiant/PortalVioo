export interface UserToCreate {
    name: string,
    address: string,
    imgPath: string
}